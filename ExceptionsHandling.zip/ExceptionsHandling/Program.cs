﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ExceptionsHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            Demo();
        }

        private static void Demo()
        {

            /*try 
            {*/
                //Worker thread//
                new Thread(Execute).Start();
            /*}
            //Main thread//
            catch(Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }*/
        }

        static void Execute() {
            try 
            {
                throw null;
            }
            catch(Exception ex)
            { 

            }
            
        }
    }
}
